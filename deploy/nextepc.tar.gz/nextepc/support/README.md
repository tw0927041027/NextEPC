
* Network Configuration
user@host ~/Documents/git/nextepc/support$ \
    sudo ./network/restart.sh

* Generate Key & Cert for Diameter
user@host ~/Documents/git/nextepc/support$ \
    ./make_certs.sh ./freeDiameter
